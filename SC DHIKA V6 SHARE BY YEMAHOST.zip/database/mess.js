require("./global")

const mess = {
   wait: "`proses`",
   success: "`sukses`",
   on: "*`on feature`", 
   off: "*`off feature`",
   query: {
       text: "`teks nya mana?`",
       link: "`link nya?`",
   },
   error: {
       fitur: "`fitur eror`",
   },
   only: {
       group: "`fitur cuma bisa di dalam group`",
       private: "`fitur cuma bisa bi privat chat`",
       owner: "`fitur Ini cuma bisa di oleh owner`",
       admin: "`fitur ini cuma bisa di akses oleh aetmin`",
       badmin: ` \`gabisa,bot ${namabot} jadiin aetmin\` `,
       premium: ` \`fitur ini cuma boleh member premium ${namabot}\` `,
   }
}

global.mess = mess

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})